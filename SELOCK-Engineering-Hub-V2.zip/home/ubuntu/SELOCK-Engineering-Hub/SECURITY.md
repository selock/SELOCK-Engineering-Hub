# Política de Segurança - SELOCK

A SELOCK leva a segurança e a privacidade a sério. Se você identificar uma vulnerabilidade em nossos ativos de engenharia, siga os procedimentos abaixo.

## Relatando uma Vulnerabilidade

Por favor, envie um e-mail para:
**geral@selock.net**

### Compromisso SELOCK:
- **Confidencialidade**: Todos os relatos são tratados com sigilo absoluto.
- **Prioridade**: Vulnerabilidades críticas recebem atenção imediata da nossa equipe de engenharia.
- **Transparência**: Manteremos o relator informado sobre o progresso da correção.

---

**Nota Interna**: Este repositório segue rigorosos padrões de compliance e não contém dados sensíveis ou referências a ferramentas externas não autorizadas.
