#!/usr/bin/env python3
"""
SELOCK Dark Web Search Engine
Inspirado em tecnologias OSINT avançadas, adaptado para a infraestrutura SELOCK.
"""

import requests
import random
import json
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Motores de busca Dark Web (Onion)
SEARCH_ENGINES = [
    {"name": "Ahmia", "url": "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/search/?q={query}"},
    {"name": "OnionLand", "url": "http://3bbad7fauom4d6sgppalyqddsqbf5u5p56b5k5uk2zxsy3d6ey2jobad.onion/search?q={query}"},
    {"name": "Torch", "url": "http://xmh57jrknzkhv6y3ls3ubitzjtbsbu7op7pbmbbzxmlrepsmw4vutad.onion/cgi-bin/arpa/front?q={query}"}
]

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0"
]

def get_tor_session():
    """Configura uma sessão HTTP via Tor SOCKS5 proxy."""
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    # Configuração padrão do Tor Proxy (localhost:9050)
    session.proxies = {
        "http": "socks5h://127.0.0.1:9050",
        "https": "socks5h://127.0.0.1:9050"
    }
    return session

def perform_search(query):
    print(f"[SELOCK-INTEL] Iniciando busca Dark Web para: {query}")
    session = get_tor_session()
    results = []
    
    for engine in SEARCH_ENGINES:
        try:
            url = engine['url'].format(query=query)
            headers = {"User-Agent": random.choice(USER_AGENTS)}
            print(f"  - Consultando {engine['name']}...")
            # Timeout longo para redes Onion
            response = session.get(url, headers=headers, timeout=45)
            if response.status_code == 200:
                results.append({
                    "engine": engine['name'],
                    "status": "success",
                    "data_length": len(response.text)
                })
        except Exception as e:
            print(f"  [!] Erro ao consultar {engine['name']}: {str(e)}")
            
    return results

if __name__ == "__main__":
    import sys
    search_query = sys.argv[1] if len(sys.argv) > 1 else "selock"
    data = perform_search(search_query)
    print(json.dumps(data, indent=4))
