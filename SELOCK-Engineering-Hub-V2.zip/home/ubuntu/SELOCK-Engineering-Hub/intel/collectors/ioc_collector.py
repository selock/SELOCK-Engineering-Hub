#!/usr/bin/env python3
"""
SELOCK-Intel-Collector
Script para coleta e normalização de Indicadores de Comprometimento (IOCs).
"""

import json

def collect_iocs():
    print("[*] Iniciando coleta de IOCs para plataformas móveis...")
    # Exemplo de IOCs normalizados
    iocs = [
        {"type": "domain", "value": "malicious-mobile-cnc.net", "severity": "high"},
        {"type": "ip", "value": "185.123.45.67", "severity": "critical"},
        {"type": "hash", "value": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "severity": "medium"}
    ]
    return iocs

def save_report(iocs):
    filename = "latest_iocs_report.json"
    with open(filename, "w") as f:
        json.dump(iocs, f, indent=4)
    print(f"[+] Relatório salvo em: {filename}")

if __name__ == "__main__":
    print("--- SELOCK Threat Intelligence ---")
    data = collect_iocs()
    save_report(data)
