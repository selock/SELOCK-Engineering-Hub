# Guia de Hardening Android - SELOCK

Este guia detalha os procedimentos de engenharia aplicados pela SELOCK para a redução da superfície de ataque em dispositivos móveis Android.

## 1. Modificações de Kernel
- **Desativação de Módulos Não Utilizados**: Remover suporte a drivers de hardware desnecessários para evitar explorações de kernel.
- **Configurações de Memória**: Habilitar proteções contra estouro de buffer e execução de código em áreas de dados.

## 2. Controle de Hardware
- **Bloqueio de Portas Físicas**: Desativação de depuração USB (ADB) em produção.
- **Gerenciamento de Sensores**: Restrição de acesso a microfone, câmera e GPS por políticas de hardware.

## 3. Comunicação Controlada
- **VPN Always-On**: Configuração obrigatória de túneis criptografados para todo o tráfego.
- **DNS Seguro**: Implementação de DNS over TLS (DoT) para evitar interceptação de consultas.

## 4. Verificação de Integridade
- **Verified Boot**: Garantir que apenas o sistema operacional assinado pela SELOCK seja carregado.
- **Attestation API**: Verificação remota do estado de segurança do dispositivo.

---
**Propriedade da SELOCK - Engenharia de Segurança**
